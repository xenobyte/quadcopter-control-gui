/*
 * Parameters.cpp
 *
 *  Created on: 22.01.2015
 *      Author: Johannes Selymes
 */

#include "Parameters.h"


